import pickle
from flask import Flask, jsonify, request, render_template
import pandas as pd

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/airbnb')
def airbnb():
    return render_template('airbnb.html')

@app.route('/categorical')
def cat():
    return render_template('Categorical.html')

@app.route('/listing')
def lis():
    return render_template('listings-2.html')

@app.route('/numerical')
def num():
    return render_template('Numerical-3.html')

@app.route('/tokyomap')
def tokyo():
    return render_template('tokyomap.html')

@app.route('/tokyomap1')
def tokyo1():
    return render_template('tokyomap1.html')

@app.route('/news')
def news():
    return render_template('news.html')

@app.route('/hasil',methods = ['POST','GET'])
def hasil():
    if request.method == 'POST':
        input = request.form
        N = float(input['N'])
        Pt = float(input['Pt'])
        Rt = float(input['Rt'])
        Ib = float(input['Ib'])
        Rpm = float(input['Rpm'])
        Rs = float(input['Rs'])
        Av = float(input['Av'])
        Gs = float(input['Gs'])
        B = float(input['B'])
        Bd = float(input['Bd'])
        Am = float(input['Am'])
        Sd = float(input['Sd'])
        Cf = float(input['Cf'])
        Ep = float(input['Ep'])
        Cl = float(input['Cl'])
        Ht = float(input['Ht'])
        Wf = float(input['Wf'])
        Ac = float(input['Ac'])
        Hd = float(input['Hd'])
        Rg = float(input['Rg'])
        So = float(input['So'])
        El = float(input['El'])
        Kc = float(input['Kc'])
        Ws = float(input['Ws'])
        Tv = float(input['Tv'])
        Fr = float(input['Fr'])
        Hw = float(input['Hw'])
        Hr = float(input['Hr'])
        Sm = float(input['Sm'])
        Amn = float(input['Amn'])
        Hv = float(input['Hv'])
        data = [[N,Pt,Rt,Ib,Rpm,Rs,Av,Gs,B,Bd,Am,Sd,Cf,Ep,Cl,Ht,Wf,Ac,Hd,Rg,So,El,Kc,Ws,Tv,Fr,Hw,Hr,Sm,Amn,Hv]]

        kolom = ['neighbourhood_cleansed', 'property_type', 'room_type',
                 'instant_bookable', 'reviews_per_month', 'review_scores_rating',
                 'availability_365', 'guests_included', 'beds', 'bedrooms',
                 'accommodates', 'security_deposit', 'cleaning_fee', 'extra_people', 'cancellation', 'heating', 'wifi',
                 'ac',
                 'hairdryer', 'refrigerator', 'smoke', 'essentials', 'kitchen', 'washer',
                 'TV', 'fire_ex', 'hotwater', 'hanger', 'shampoo', 'num_amenities',
                 'num_verifications']
        df = pd.DataFrame(data=data, columns=kolom)
        pred = Model.predict(df)[0]

        return render_template('hasil.html',data=input,prediksi=pred)


    return render_template('hasil.html')


if __name__ == "__main__":
    with open('XGBReg', 'rb') as model:
        Model = pickle.load(model)
    app.run(debug=True)

